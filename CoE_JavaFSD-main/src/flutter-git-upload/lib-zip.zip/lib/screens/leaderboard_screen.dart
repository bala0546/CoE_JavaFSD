import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final leaderboardBox = Hive.box('leaderboard');
    List<Map> leaderboardEntries = List<Map>.from(leaderboardBox.get('entries') ?? []);

    return Scaffold(
      appBar: AppBar(title: const Text('Leaderboard')),
      body: leaderboardEntries.isEmpty
          ? const Center(child: Text("No leaderboard data yet."))
          : ListView.builder(
              itemCount: leaderboardEntries.length,
              itemBuilder: (context, index) {
                final entry = leaderboardEntries[index];
                return ListTile(
                  leading: Text("#${index + 1}"),
                  title: Text(entry['name']),
                  subtitle: Text("Time Taken: ${entry['time']} sec | Score: ${entry['score']}"),
                );
              },
            ),
    );
  }
}
