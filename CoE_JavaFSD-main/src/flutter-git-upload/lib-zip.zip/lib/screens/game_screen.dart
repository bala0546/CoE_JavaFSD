import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../widgets/game_card.dart';
import 'dart:async';
import 'home_screen.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({Key? key}) : super(key: key);

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late List<String> _gameData;
  late List<bool> _cardFlipped;
  late int _score;
  late int _timeLeft;
  late String _firstSelectedCard;
  late int _firstSelectedIndex;
  late bool _isGameOver;
  late String playerName;
  Timer? _timer;
  late int _startTime;

  @override
  void initState() {
    super.initState();
    playerName = '';
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _askPlayerName();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _askPlayerName() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        String tempName = '';
        return AlertDialog(
          title: const Text("Enter Your Name"),
          content: TextField(
            onChanged: (value) => tempName = value,
            decoration: const InputDecoration(hintText: "Player Name"),
          ),
          actions: [
            TextButton(
              onPressed: () {
                if (tempName.isNotEmpty) {
                  setState(() {
                    playerName = tempName;
                    _initializeGame();
                  });
                  Navigator.pop(context);
                }
              },
              child: const Text("Start Game"),
            ),
          ],
        );
      },
    );
  }

  void _initializeGame() {
    setState(() {
      _gameData = ['🍎', '🍌', '🍇', '🍓', '🍊', '🍉', '🍎', '🍌', '🍇', '🍓', '🍊', '🍉'];
      _gameData.shuffle();
      _cardFlipped = List.generate(_gameData.length, (index) => false);
      _score = 0;
      _timeLeft = 45;
      _firstSelectedCard = '';
      _firstSelectedIndex = -1;
      _isGameOver = false;
      _startTime = DateTime.now().millisecondsSinceEpoch;
    });
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timeLeft > 0 && !_isGameOver) {
        setState(() {
          _timeLeft--;
        });
      } else {
        timer.cancel();
        _endGame();
      }
    });
  }

  void _flipCard(int index) {
    if (_cardFlipped[index] || _isGameOver) return;

    setState(() {
      _cardFlipped[index] = true;
    });

    if (_firstSelectedCard.isEmpty) {
      _firstSelectedCard = _gameData[index];
      _firstSelectedIndex = index;
    } else {
      if (_gameData[index] == _firstSelectedCard) {
        setState(() {
          _score += 10;
          _firstSelectedCard = '';
          _firstSelectedIndex = -1;
          if (_cardFlipped.every((flipped) => flipped)) {
            _endGame();
          }
        });
      } else {
        Future.delayed(const Duration(seconds: 1), () {
          setState(() {
            _cardFlipped[index] = false;
            _cardFlipped[_firstSelectedIndex] = false;
            _firstSelectedCard = '';
            _firstSelectedIndex = -1;
          });
        });
      }
    }
  }

  void _endGame() {
    setState(() {
      _isGameOver = true;
    });

    int completionTime = DateTime.now().millisecondsSinceEpoch - _startTime;
    completionTime = (completionTime / 1000).round();

    final leaderboardBox = Hive.box('leaderboard');

    // Prevent duplicate entries in leaderboard
    bool exists = false;
    List<Map> leaderboardEntries = List<Map>.from(leaderboardBox.get('entries') ?? []);
    for (var entry in leaderboardEntries) {
      if (entry['name'] == playerName) {
        exists = true;
        break;
      }
    }

    if (!exists) {
      leaderboardEntries.add({'name': playerName, 'score': _score, 'time': completionTime});
      leaderboardEntries.sort((a, b) => a['time'].compareTo(b['time'])); // Sort by time taken
      leaderboardBox.put('entries', leaderboardEntries);
    }

    _showGameOverDialog(completionTime);
  }

  void _showGameOverDialog(int completionTime) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Game Over'),
        content: Text('$playerName, your score: $_score\nCompletion Time: $completionTime sec'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _initializeGame();
            },
            child: const Text('Restart'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => const HomeScreen()),
                (route) => false,
              );
            },
            child: const Text('Home'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Memory Training Game - $playerName'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Time Left: $_timeLeft sec | Score: $_score'),
          ),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              padding: const EdgeInsets.all(16.0),
              itemCount: _gameData.length,
              itemBuilder: (context, index) {
                return GameCard(
                  text: _cardFlipped[index] ? _gameData[index] : '❓',
                  onTap: () => _flipCard(index),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
