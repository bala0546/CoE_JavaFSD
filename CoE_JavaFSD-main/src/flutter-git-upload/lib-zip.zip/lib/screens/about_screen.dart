import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("About the Game")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Game Title
            const Center(
              child: Text(
                "🧠 Memory Training Game 🎯",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 15),

            // Introduction
            const Text(
              "Welcome to the Memory Training Game! This game is designed to boost your cognitive skills by challenging your memory and concentration.",
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),

            // How to Play Section
            _buildSectionTitle("🎮 How to Play"),
            _buildBulletPoint("Tap on a card to reveal the hidden symbol."),
            _buildBulletPoint("Find the matching pair by remembering the previous cards."),
            _buildBulletPoint("Match all pairs within the time limit to win!"),
            _buildBulletPoint("Your completion time will be recorded in the leaderboard."),
            const SizedBox(height: 20),

            // Benefits Section
            _buildSectionTitle("🚀 Benefits of Playing"),
            _buildBulletPoint("Enhances memory retention."),
            _buildBulletPoint("Improves concentration and problem-solving skills."),
            _buildBulletPoint("Great way to exercise your brain and have fun!"),
            const SizedBox(height: 20),

            // A Fun Fact
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                "💡 Fun Fact: Regularly playing memory games can delay cognitive decline by up to 10 years!",
                style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
              ),
            ),
            const SizedBox(height: 30),

            // Back Button
            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.arrow_back),
                label: const Text("Back to Home"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper Method for Section Titles
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  // Helper Method for Bullet Points
  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 10, bottom: 5),
      child: Row(
        children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 18),
          const SizedBox(width: 5),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
