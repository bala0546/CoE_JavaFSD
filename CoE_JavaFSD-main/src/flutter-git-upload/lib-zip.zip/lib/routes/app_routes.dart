class AppRoutes {
  static const String home = '/';
  static const String game = '/game';
  static const String leaderboard = '/leaderboard';
  static const String settings = '/settings';
  static const String about = '/about'; // Ensure this is present
}
