import 'package:flutter/material.dart';

// Define commonly used colors
class AppColors {
  static const primary = Colors.blue;
  static const secondary = Colors.teal;
  static const backgroundLight = Colors.white;
  static const backgroundDark = Colors.black;
  static const textLight = Colors.black;
  static const textDark = Colors.white;
}

// Define font sizes
class AppFontSizes {
  static const small = 12.0;
  static const medium = 16.0;
  static const large = 20.0;
  static const xLarge = 24.0;
}

// Define spacing constants
class AppSpacing {
  static const small = 8.0;
  static const medium = 16.0;
  static const large = 24.0;
}
