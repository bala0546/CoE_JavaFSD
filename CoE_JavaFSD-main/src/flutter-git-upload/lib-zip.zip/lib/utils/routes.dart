import 'package:flutter/material.dart';
import '../screens/home_screen.dart';
import '../screens/game_screen.dart';
import '../screens/leaderboard_screen.dart';
import '../screens/settings_screen.dart';
import '../screens/how_to_play_screen.dart';

class AppRoutes {
  static const String home = '/';
  static const String game = '/game';
  static const String leaderboard = '/leaderboard';
  static const String settings = '/settings';
  static const String howToPlay = '/how-to-play';

  static Map<String, WidgetBuilder> getRoutes() {
    return {
      home: (context) => const HomeScreen(),
      game: (context) => const GameScreen(),
      leaderboard: (context) => const LeaderboardScreen(),
      settings: (context) => const SettingsScreen(),
      howToPlay: (context) => const HowToPlayScreen(),
    };
  }
}
