import { Routes } from '@angular/router';
import { TaskListComponent } from './components/task-list/task-list.component';
import { SettingsComponent } from './components/settings/settings.component';
import { LoginComponent } from './components/login/login.component';
import { AboutComponent } from './components/about/about.component'; // ✅ Import About Component
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },  
  { path: 'login', component: LoginComponent }, 
  { path: 'tasks', component: TaskListComponent, canActivate: [AuthGuard] }, 
  { path: 'settings', component: SettingsComponent, canActivate: [AuthGuard] }, 
  { path: 'about', component: AboutComponent }, // ✅ Add About Page Route
  { path: '**', redirectTo: 'login' } 
];
