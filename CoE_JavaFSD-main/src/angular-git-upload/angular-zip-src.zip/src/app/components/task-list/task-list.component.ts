import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskItemComponent } from '../task-item/task-item.component';
import { TaskFormComponent } from '../task-form/task-form.component';
import { TaskService } from '../../services/task.service'; // ✅ Import TaskService
import { Task } from '../../models/task.model'; // ✅ Import Task Model

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, TaskItemComponent, TaskFormComponent],
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss'] // ✅ Corrected property name
})
export class TaskListComponent implements OnInit {
  tasks: Task[] = [];
  theme: string = 'light'; // ✅ Add theme property

  constructor(private taskService: TaskService) {} // ✅ Inject TaskService

  ngOnInit() {
    this.loadTasks();
    this.loadTheme(); // ✅ Load theme from localStorage
  }

  loadTasks() {
    this.taskService.getTasks().subscribe(
      (tasks) => (this.tasks = tasks),
      (error) => console.error('Error fetching tasks:', error)
    );
  }

  addTask(newTask: { id: number; name: string }) {
    const task: Task = { ...newTask, completed: false }; // Ensure it matches Task model
    this.taskService.addTask(task);
    this.loadTasks();
  }
  

  removeTask(taskId: number) {
    this.taskService.deleteTask(taskId);
    this.loadTasks();
  }

  updateTask(updatedTask: Task) {
    this.taskService.updateTask({ ...updatedTask }); // Ensure full Task object is passed
    this.loadTasks();
  }
  

  toggleTaskCompletion(taskId: number) {
    this.taskService.toggleTaskCompletion(taskId);
    this.loadTasks();
  }

  private loadTheme() {
    this.theme = localStorage.getItem('theme') || 'light'; // ✅ Retrieve saved theme
  }
}
