import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // ✅ Import FormsModule for ngModel
import { Task } from '../../models/task.model'; // ✅ Import Task Model

@Component({
  selector: 'app-task-item',
  standalone: true,
  imports: [CommonModule, FormsModule], // ✅ Add FormsModule
  templateUrl: './task-item.component.html',
  styleUrl: './task-item.component.scss'
})
export class TaskItemComponent {
  @Input() task!: Task; // ✅ Use Task model
  @Output() deleteTask = new EventEmitter<number>();
  @Output() updateTask = new EventEmitter<Task>(); // ✅ Use full Task object
  @Output() toggleComplete = new EventEmitter<number>(); // ✅ New event emitter

  isEditing = false;
  editedTaskName = '';

  startEditing() {
    this.isEditing = true;
    this.editedTaskName = this.task.name;
  }

  saveEdit() {
    if (this.editedTaskName.trim()) {
      this.updateTask.emit({ id: this.task.id, name: this.editedTaskName, completed: this.task.completed }); // ✅ Include "completed"
      this.isEditing = false;
    }
  }

  removeTask() {
    this.deleteTask.emit(this.task.id);
  }

  toggleCompletion() {
    this.toggleComplete.emit(this.task.id); // ✅ Emit task completion change
  }
}
