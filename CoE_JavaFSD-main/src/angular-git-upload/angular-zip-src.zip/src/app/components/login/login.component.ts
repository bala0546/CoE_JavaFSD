import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule], // ✅ Ensure FormsModule is used correctly
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  username = '';
  password = '';
  returnUrl: string = '/tasks';

  constructor(private router: Router, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.returnUrl = params['returnUrl'] || '/tasks';
    });
  }

  login() {
    if (this.username.trim() === 'admin' && this.password === 'password') {
      localStorage.setItem('isAuthenticated', 'true'); 
      this.router.navigateByUrl(this.returnUrl);
    } else {
      alert('❌ Invalid credentials! Try again.');
    }
  }
}
