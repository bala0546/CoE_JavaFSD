import { Component, OnInit, Renderer2 } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule], 
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  theme: string = 'light'; 

  constructor(private router: Router, private renderer: Renderer2) {} 

  ngOnInit() {
    const savedTheme = localStorage.getItem('theme') || 'light'; 
    this.theme = savedTheme;
    this.applyTheme(savedTheme); 
  }

  changeTheme(newTheme: string) {
    this.theme = newTheme;
    localStorage.setItem('theme', newTheme); 
    this.applyTheme(newTheme); 
  }

  applyTheme(theme: string) {
    const body = document.body;
    if (theme === 'dark') {
      this.renderer.addClass(body, 'dark-theme');
      this.renderer.removeClass(body, 'light-theme');
    } else {
      this.renderer.addClass(body, 'light-theme');
      this.renderer.removeClass(body, 'dark-theme');
    }
  }

  logout() { 
    localStorage.removeItem('isAuthenticated'); 
    this.router.navigate(['/login']); 
  }
}
