import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [CommonModule, FormsModule], // ✅ Import FormsModule for ngModel
  templateUrl: './task-form.component.html',
  styleUrl: './task-form.component.scss'
})
export class TaskFormComponent {
  @Output() taskAdded = new EventEmitter<{ id: number; name: string }>(); // ✅ Emit new task
  taskName: string = ''; // ✅ Two-way bound input field
  errorMessage: string = ''; // ✅ Error message for validation

  addTask() {
    if (!this.taskName.trim()) {
      this.errorMessage = 'Task name cannot be empty!'; // ✅ Show error message
      return;
    }

    const newTask = { id: Date.now(), name: this.taskName }; // ✅ Generate unique ID
    this.taskAdded.emit(newTask); // ✅ Notify parent
    this.taskName = ''; // ✅ Reset input field
    this.errorMessage = ''; // ✅ Clear error message
  }
}
