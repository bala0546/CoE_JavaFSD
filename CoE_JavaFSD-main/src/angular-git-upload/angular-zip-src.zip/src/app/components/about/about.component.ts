import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './about.component.html', // ✅ External HTML
  styleUrl: './about.component.scss' // ✅ External SCSS
})
export class AboutComponent {}
