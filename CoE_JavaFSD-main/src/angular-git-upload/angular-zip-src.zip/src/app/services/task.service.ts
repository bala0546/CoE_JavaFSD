import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Task } from '../models/task.model';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private tasksSubject: BehaviorSubject<Task[]> = new BehaviorSubject<Task[]>(this.loadTasks());
  tasks$: Observable<Task[]> = this.tasksSubject.asObservable();

  constructor() {}

  private loadTasks(): Task[] {
    const storedTasks = localStorage.getItem('tasks');
    return storedTasks ? JSON.parse(storedTasks) : [];
  }

  private saveTasks(tasks: Task[]): void {
    localStorage.setItem('tasks', JSON.stringify(tasks));
    this.tasksSubject.next(tasks);
  }

  getTasks(): Observable<Task[]> {
    return this.tasks$;
  }

  addTask(newTask: Task): void {
    const tasks = [...this.tasksSubject.value, newTask];
    this.saveTasks(tasks);
  }

  deleteTask(taskId: number): void {
    const tasks = this.tasksSubject.value.filter(task => task.id !== taskId);
    this.saveTasks(tasks);
  }

  updateTask(updatedTask: Task): void {
    const tasks = this.tasksSubject.value.map(task => 
      task.id === updatedTask.id ? { ...task, name: updatedTask.name } : task
    );
    this.saveTasks(tasks);
  }

  toggleTaskCompletion(taskId: number): void {
    const tasks = this.tasksSubject.value.map(task => 
      task.id === taskId ? { ...task, completed: !task.completed } : task
    );
    this.saveTasks(tasks);
  }
}
